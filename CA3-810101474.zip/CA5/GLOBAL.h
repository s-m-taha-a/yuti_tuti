#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "STRUCT.h"
#include "SIGNUP.h"
#include "LOGIN.h"
#include "LOGOUT.h"
#include "POST.h"
#include "INFO.h"
#include "FIND.h"
#include "DELETE.h"

