#include "GLOBAL.h"
int main()
{
    head_of_list.next = NULL;
    man = NULL;

    while (1)
    {
        printf("\a");
        printf("\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\n");
        printf("enter your selection-->");
        printf("1)signup <user_name> <password> */* 2)login <user_name> <password> */* 3)logout */* 4)post <text> */* 5)delete <post_id> */* 6)info */* find <user_name> ~~~\n");
        char *commond;
        scanf("%[^ ^\n]%*c", commond);
        char order[1];
        if (!strcmp(commond, "signup"))
        {
            signup();
        }
        else if (!strcmp(commond, "login"))
        {
            login();
        }
        else if (!strcmp(commond, "post"))
        {
            post();
        }
        else if (!strcmp(commond, "logout"))
        {
            logout();
        }
        else if (!strcmp(commond, "find"))
        {
            find();
        }
        else if (!strcmp(commond, "info"))
        {
            info();
        }
        else if (!strcmp(commond, "delete"))
        {
            delete ();
        }
        else
        {
            system("cls");
            printf("your enter is wrong\n");
        }
    }
}
