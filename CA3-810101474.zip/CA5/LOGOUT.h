int logout()
{
    man = NULL;
    printf("you are logged out!\n");
}