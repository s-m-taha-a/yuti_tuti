int login()
{
    char a[100], b[100];
    scanf("%[^ ]%*c", a);
    scanf("%[^\n]%*c", b);
    if (man)/*aghar login karde boood */
    {
        printf("you are already loggid in!\n");
    }
    else
    {
        yuti_tuti *swap = head_of_list.next; /*motaghayer swap baray peimayesh list tarif mikonim*/
        int i;
        for (i = 0; swap; swap = swap->next) /*list ra ta akhar peimayesh mikonim*/
        {
            if (!strcmp(a, swap->user_name)) /*aghar username ba username dar list barabar bood mire jolo*/
            {
                if (!strcmp(b, swap->password)) /*aghar password ba password dar list barabar bood vared account mishe*/
                {
                    i = -10;
                    man = swap;
                    printf("you login in this account!\n");
                    break;
                }
                else
                {
                    printf("the password is wrong!\n");
                }
            }
        }
        if (i > 0)
        {
            printf("this account does not exist!\n");
        }
    }
}