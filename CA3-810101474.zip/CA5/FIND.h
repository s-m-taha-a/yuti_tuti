int find()
{
    char user[500];
    yuti_tuti *user_find = head_of_list.next;
    scanf("%[^\n]%*c", user);
    if (man)/*aghar login karde boood */
    {
        for (; user_find; user_find = user_find->next)/*peymayesh list*/
        {
            if (!strcmp(user_find->user_name, user))
            {
                printf("============================\nname is %s \n user_id %d \n=============================\n", user_find->user_name, user_find->user_id);
                posting *swap = user_find->poster;
                for (; swap; swap = swap->next)/*peymayesh list*/
                {
                    printf("id : %d \n %s \n like : %d \n-----------------------------------------------------\n", swap->post_id, swap->matn, swap->num_of_like);
                }
                break;
            }
        }
    }
    else
    {
        printf("please login and finding!\n");
    }
}