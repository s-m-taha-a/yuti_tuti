int delete()
{

    if (man)/*aghar login karde boood */
    {
        int del;
        scanf(" %d", &del);
        posting *del_user = man->poster;
        posting *bef_user = man->poster;
        if (del_user->next)
        {
            if (del_user->post_id != del)
            {
                for (; del_user; del_user = del_user->next)/*peymayesh list*/
                {
                    if (del_user->post_id == del)
                    {
                        
                        bef_user->next = del_user->next;
                        printf("your post is deleted!\n");
                        free(del_user);
                        break;
                    }
                    bef_user = del_user;
                }
            }
            else
            {
                man->poster = man->poster->next;
                free(del_user);
            }
        }
        else if (del_user->post_id = del)
        {
            man->poster = NULL;
            free(del_user);
        }
    }
    else
    {
        printf("pleese login!\n");
    }
}