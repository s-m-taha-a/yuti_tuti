typedef struct YUTI_TUTI
{
    char *user_name;
    char *password;
    int user_id;
    struct YUTI_TUTI *next;
    struct POSTING *poster;
} yuti_tuti;
typedef struct POSTING
{
    char *matn;
    int post_id;
    int num_of_like;
    char likers[200];
    struct POSTING *next;
} posting;
yuti_tuti *man;
yuti_tuti head_of_list;