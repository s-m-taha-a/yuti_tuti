int post()
{
    if (man)/*aghar login karde boood */
    {
        char word[1000];
        scanf("%[^\n]%*c", word);
        posting *one = (posting *)malloc(sizeof(posting));   /*tarif motaghayye va rikhtan meghdar dar an v malloc kardan*/
        one->matn = (char *)malloc(sizeof(char) * strlen(word));
        strcpy(one->matn, word); /*kcopy kardane matn*/
        if (man->poster)
        {
            posting *two = man->poster;
            for (; two->next; two = two->next) /*peymayesh list*/
                ;
            two->next = one;
            one->post_id = (two->post_id) + 1;
        }
        else
        {
            man->poster = one;
            one->post_id = 1;
        }
        one->num_of_like = 0;
        one->next = NULL;
    }
    else
    {
        printf("please login next posting!\n");
    }
}