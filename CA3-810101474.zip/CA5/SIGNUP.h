int signup()
{                                                                 /*sare list ra az hamin avval null mizarim*/
    yuti_tuti *new_user = (yuti_tuti *)malloc(sizeof(yuti_tuti)); /*karbare jadid tarif mikonim*/
    new_user->password = (char *)malloc(sizeof(char));            /*be motaghayyer haye karbar hafeze midim*/
    new_user->user_name = (char *)malloc(sizeof(char));
    new_user->user_id = 1; /*userid ra by deafult yek gharar midim*/
    char a[100], b[100];   /*baraye varred kardan esm v ramz az in char ha estefade mikonim*/
    int j = 10;            /*in halghe ra baraye in ke betavanim struct ro jh hov ppor konim*/
    scanf("%[^ ]%*c", a);  /*username v password ro migirim*/
    scanf("%[^\n]%*c", b);
    yuti_tuti *swap = head_of_list.next; /*motaghayer swap baray peimayesh list tarif mikonim*/
    strcpy(new_user->user_name, a);      /*username v password ro mirizim dar jaye marboteh*/
    strcpy(new_user->password, b);
    for (; swap; swap = swap->next)
    {
        if (!strcmp(a, swap->user_name))
        {
            j = -10;
            printf("this account exist!\n");
        }
    }
    if (j > 0)
    {

        if (head_of_list.next == NULL) /*aghar hanoz karbari vared nashoodeh*/
        {
            // printf("%s    %s    %d\n", new_user->user_name, new_user->password, new_user->user_id);
            printf("your account added successfully!\n");
            head_of_list.next = new_user; /*hereye jadid ro iadid mikonim*/
            new_user->next = NULL;
            new_user->poster = NULL;
        }

        else
        {

            for (swap = head_of_list.next; swap->next; swap = swap->next) /*list ra ta akhar peimayesh mikonim*/
                ;
            swap->next = new_user;                   /*maghadir jadid ra jayghozri mikonim*/
            new_user->user_id = (swap->user_id) + 1; /*userid ra har dafe ziiyad mikonim*/
            new_user->next = NULL;
            printf("your account added successfully!\n");
            new_user->poster = NULL;
        }
    }
}