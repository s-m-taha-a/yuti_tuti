int info()
{
    if (man) /*aghar login karde boood */
    {
        printf("============================\nname is %s \n password is %s \n user_id %d \n=============================\n", man->user_name, man->password, man->user_id);
        posting *swap = man->poster; /*motaghayyer tarif mikonim va an ra meghdar miduim ta swap konim*/
        for (; swap; swap = swap->next)/*peymayesh list*/
        {
            printf("id : %d \n %s \n like : %d \n-----------------------------------------------------\n", swap->post_id, swap->matn, swap->num_of_like);
        }
    }
    else
    {
        printf("please login next catching info!\n");
    }
}